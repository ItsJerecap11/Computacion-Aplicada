#!/bin/bash

#Guia de usuario
if [[ "$1" == "-help" ]]; then
	echo "Usted ingreso a la guia de usuario"
echo "Uso: Seguido del nombre del script debe indicar el directorio de origen seguido del directorio destino"
	echo "Formato: backup_full.sh <origen> <destino>"
	echo "En caso de no ingresar un destino, se dirigira automaticamente a /backup_dir"
	exit 0
fi

#Validacion de argumentos
if [[ $# -lt 1 ]]; then
	echo "Error: Se necesita al menos el directorio de origen"
	echo "Use -help para ingresar a la guia de usuario"
	exit 1
fi

#Asignacion de variables
ORIGEN=$1

if [ $# -eq 1 ]; then
	DESTINO=/backup_dir
else
	DESTINO=$2
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

#Validacion de origen y destino
if [ ! -d "$ORIGEN" ]; then
	echo "Error: No se encontro el directorio origen $ORIGEN"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: No se encontro el directorio destino $DESTINO"
	exit 1
fi

#Realizar backup
echo "Realizando el backup..."
tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"
echo "Backup de $ORIGEN realizado correctame en $DESTINO"
