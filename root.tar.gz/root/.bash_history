history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ls
cd /home/
ls
cd lost+found/
ls
cd ..
cd compartido/
ls
ls -a
ls -l
cd dir1/
ls
ls
ls -la
cd ..
ls
cat arch1
cat arch2
cat arch3
cat hola 
cd ..
cd ..
vi /etc/hostname 
cat /etc/hostname 
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
apt full-upgrade 
reboot
apt-cache sudo
apt-cache search sudo 
apt install sudo
sudo su
sudo su
whoami 
apt install openssh-server
apt install nano
ls
cd /home/
ls
reboot
su -
su 
exit
exit
whoami 
exit
ip a
ip a
ping 8.8.8.8
/etc/init.d/networking restart 
ping 8.8.8.8
nano /etc/network/interfaces
ip a
addr
addrr
addrres
addr
address
ifup enp0s3 
sudo shutdown -r now
shutdown -r now
ip a
nano /etc/network/interfaces
nano /etc/network/interfaces
/etc/init.d/networking restart 
ip a
nano /etc/network/interfaces
ping 8.8.8.8
ping 1.1.1.1
nano /etc/network/interfaces
/etc/init.d/networking restart 
ping 8.8.8.8
ifup enp0s3 
nano /etc/network/interfaces
/etc/init.d/networking restart 
ping 8.8.8.8
/etc/init.d/networking restart 
ifup enp0s3 
shutdown -r now
ip a
nano /etc/network/interfaces
/etc/init.d/networking restart 
ifup enp0s3 
ping 8.8.8.8
lsblk 
fdisk
fdisk /dev/sd
fdisk /dev/sd
fdisk /dev/sdd
fdisk /dev/sdc
poweroff
lsblk
reboot
lsblk
fdisk
fdisk /dev/sda
nano /etc/fstab 
fdisk
lsblk
fdisk /dev/sdc
lsblk
fdisk /dev/sdc
lsblk 
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkfs.ext4 /dev/sdc2
lsblk 
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir/
mount /dev/sdc2 /backup_dir/
lsblk 
lsblk 
nano /etc/fstab 
mount -a
nano /etc/fstab 
lsblk 
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
cd /www_dir/
ls
nano /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
curl http://192.168.101.16/index/php
chmod 755 /www_dir/
chmod 644 /www_dir/index.php 
chmod 644 /www_dir/logo.png 
curl http://192.168.101.16/index/php
nano /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
curl http://192.168.101.16/index/php
ip a
shutdown
shutdown -c
shutdown -c
shutdown -c
shutdown
shutdown now
lsblk 
cd /www_dir/
ls
la
ls la
ls -la
nano /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
curl http://192.168.101.16/index/php
nano /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
systemctl restart apache2
systemctl status apache2.service 
systemctl restart apache2
reboot
systemctl status apache2.service 
nano /etc/apache2/sites-available/000-default.conf 
systemctl status apache2.service 
reboot
